import { View, Text } from 'react-native'
import React from 'react'

export default function Favorite() {
  return (
    <View>
      <Text>Favorite</Text>
    </View>
  )
}