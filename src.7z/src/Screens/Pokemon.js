import { View, Text } from 'react-native'
import React from 'react'

export default function Pokemon() {
  return (
    <View>
      <Text>Pokemon</Text>
    </View>
  )
}